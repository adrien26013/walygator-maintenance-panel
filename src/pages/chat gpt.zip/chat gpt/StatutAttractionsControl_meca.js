import React, { useEffect, useMemo, useState, useRef } from "react";
import {
  collection,
  doc,
  setDoc,
  onSnapshot,
  serverTimestamp,
  addDoc,
  query,
  where,
  getDocs,
} from "firebase/firestore";
import { db, auth } from "../../firebase";
import { signOut } from "firebase/auth";
import { useNavigate } from "react-router-dom";
import attractionsList from "../../data/attractionsList";

/* 🔒 NORMALISATION IDENTIQUE À FLUTTER */
const normalizeAttraction = (s) =>
  String(s || "")
    .trim()
    .toLowerCase()
    .replace(/[àâä]/g, "a")
    .replace(/[éèêë]/g, "e")
    .replace(/[îï]/g, "i")
    .replace(/[ôö]/g, "o")
    .replace(/[ùûü]/g, "u")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_|_$/g, "");

const toDate = (ts) => {
  if (!ts) return null;
  if (typeof ts.toDate === "function") return ts.toDate();
  const d = new Date(ts);
  return isNaN(d.getTime()) ? null : d;
};

const isSameDay = (a, b) =>
  a.getFullYear() === b.getFullYear() &&
  a.getMonth() === b.getMonth() &&
  a.getDate() === b.getDate();

export default function StatutAttractionsControlMeca() {
  const navigate = useNavigate();

  const [statuses, setStatuses] = useState({});
  const [validatedToday, setValidatedToday] = useState(new Set());
  const [nonSignedToday, setNonSignedToday] = useState(new Set());

  const [incidentModal, setIncidentModal] = useState(null);
// { key, name, statut }

const [incidentReason, setIncidentReason] = useState("");

// ⏱ Incidents actifs (chrono panne)
const [incidentsActifs, setIncidentsActifs] = useState({});

const lastDayRef = useRef(null);

  const today0 = useMemo(() => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}, []);

// 🔄 Tick minute pour forcer recalcul jour (ANTI FREEZE)
const [dayTick, setDayTick] = useState(0);

useEffect(() => {
  const t = setInterval(() => {
    setDayTick((x) => x + 1);
  }, 60000); // 1 min

  return () => clearInterval(t);
}, []);

// ⏱ tick UI pour chrono (local, fluide)
const [, forceTick] = useState(0);

useEffect(() => {
  const t = setInterval(() => {
    forceTick((x) => x + 1);
  }, 1000);

  return () => clearInterval(t);
}, []);


  /* 🔥 Statuts */
  useEffect(() => {
  return onSnapshot(collection(db, "attractionStatus"), (snap) => {
    const out = {};
    snap.forEach((d) => {
      out[d.id] = d.data();
    });
    setStatuses(out);
  });
}, []);

  /* 🔥 Incidents actifs (pannes en cours) */
useEffect(() => {
  const q = query(
    collection(db, "incidents"),
    where("actif", "==", true),
    where("zone", "==", "meca")
  );

  return onSnapshot(q, (snap) => {
    const map = {};
    snap.forEach((d) => {
      const data = d.data();
      map[data.attractionKey] = {
        id: d.id,
        ...data,
      };
    });
    setIncidentsActifs(map);
  });
}, []);

  /* 🔥 Checklists journalières MÉCA */
  /* 🔥 CHECKLISTS MÉCA — RESET ROBUSTE À MINUIT */
useEffect(() => {
  return onSnapshot(collection(db, "checklists"), (snap) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (
      !lastDayRef.current ||
      lastDayRef.current.getTime() !== today.getTime()
    ) {
      console.info("🔄 [PC] Nouveau jour détecté");

      lastDayRef.current = today;
      setValidatedToday(new Set());
      setNonSignedToday(new Set());
    }

    const validated = new Set();
    const signed = new Set();
    const nonSigned = new Set();

    snap.forEach((docSnap) => {
      const d = docSnap.data();
      if (d?.type !== "journaliere") return;

      const ts = toDate(d.timestamp);
      if (!ts) return;

      const t0 = new Date(ts);
      t0.setHours(0, 0, 0, 0);
      if (t0.getTime() !== today.getTime()) return;

      const attractions = Array.isArray(d.attractions)
        ? d.attractions
        : d.attraction
        ? [d.attraction]
        : [];

      attractions.forEach((a) => {
        const key = normalizeAttraction(a);
        validated.add(key);
        d.signed ? signed.add(key) : nonSigned.add(key);
      });
    });

    signed.forEach((k) => nonSigned.delete(k));

    setValidatedToday(validated);
    setNonSignedToday(nonSigned);
  });
}, [dayTick]);

const todayISO = () => {
  const d = new Date();
  return d.toISOString().slice(0, 10); // YYYY-MM-DD
};

// ⏱ Format durée arrêt attraction (UI fiable)
const formatDuration = (incident) => {
  if (!incident?.startMs) return "00:00:00";

  const diff = Math.floor((Date.now() - incident.startMs) / 1000);

  const h = String(Math.floor(diff / 3600)).padStart(2, "0");
  const m = String(Math.floor((diff % 3600) / 60)).padStart(2, "0");
  const s = String(diff % 60).padStart(2, "0");

  return `${h}:${m}:${s}`;
};

  /* 🎛 Action PC sécurité */
const updateStatus = async (key, statut) => {
  if (nonSignedToday.has(key)) return;

  await setDoc(
  doc(db, "attractionStatus", key),
  {
    status: statut,
    manual: true,
    manual_at: serverTimestamp(),
    updated_at: serverTimestamp(),
    source: "pc_securite",
    parc: "meca",
  },
  { merge: true }
);

  // 🔥 SI ON QUITTE LA PANNE → ON CLÔTURE L’INCIDENT
  if (statut !== "panne") {
    await closeIncidentIfAny(key);
  }
};

const closeIncidentIfAny = async (key) => {
  const q = query(
    collection(db, "incidents"),
    where("attractionKey", "==", key),
    where("actif", "==", true)
  );

  const snap = await getDocs(q);

  for (const d of snap.docs) {
    await setDoc(
      d.ref,
      {
        actif: false,               // 🔥 FIN OFFICIELLE
        closedAt: serverTimestamp(),
        updated_at: serverTimestamp(),
      },
      { merge: true }
    );
  }
};

  const triggerPanneWithIncident = async ({ key, name, reason }) => {
  if (nonSignedToday.has(key)) return;

  const now = Date.now();
  const sessionId = now.toString(); // 🔑 CRÉATION UNIQUE

  // 1️⃣ Mettre l’attraction en panne
  await setDoc(
    doc(db, "attractionStatus", key),
    {
      status: "panne",
      manual: true,
      manual_at: serverTimestamp(),
      updated_at: serverTimestamp(),
      source: "pc_securite",
    },
    { merge: true }
  );

  // 2️⃣ Clôturer incidents existants
  const q = query(
    collection(db, "incidents"),
    where("attractionKey", "==", key),
    where("actif", "==", true)
  );

  const snap = await getDocs(q);

  for (const d of snap.docs) {
    await setDoc(
      d.ref,
      {
        actif: false,
        closedAt: serverTimestamp(),
        updated_at: serverTimestamp(),
      },
      { merge: true }
    );
  }

  // 3️⃣ Créer NOUVEL incident
  await addDoc(collection(db, "incidents"), {
    attraction: name,
    attractionKey: key,
    zone: "meca",

    // 🔑 SESSION INCIDENT
    sessionId,

    // ⏱️ CHRONO
    startMs: now,
    startTime: serverTimestamp(),

    typeIncident: "panne",
    raisonPanne: reason,

    actif: true,
    source: "pc_securite",
    dateJour: todayISO(),
  });
};

  const handleLogout = async () => await signOut(auth);

  const colors = {
    fermee: "#ffb5b5",
    ouverte: "#b6ffb6",
    panne: "#fff3b0",
    evacuation: "#c3d9ff",
  };

  const translateStatus = (s) => {
    if (s === "panne") return "En panne";
    if (s === "evacuation") return "Évacuation en cours…";
    if (s === "ouverte") return "Ouverte";
    if (s === "fermee") return "Fermée";
    return s;
  };

  const isCurrent = (current, button) => current === button;

  return (
    <div style={{ padding: 0 }}>
      {/* 🔝 HEADER MÉCANIQUE — IDENTIQUE AQUA */}
      <div
        style={{
          width: "100%",
          height: 95,
          backgroundColor: "#235630",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          position: "relative",
        }}
      >
        {/* ← RETOUR PANEL */}
        <button
          onClick={() => navigate("/")}
          style={{
            position: "absolute",
            left: 20,
            backgroundColor: "#2f6f3a",
            border: "3px solid #f5c400",
            padding: "8px 18px",
            borderRadius: 10,
            color: "white",
            fontWeight: "bold",
          }}
        >
          ← Retour Panel
        </button>

        {/* ONGLET PARCS */}
        <div style={{ position: "absolute", left: 220, display: "flex", gap: 8 }}>
          <button
            style={{
              backgroundColor: "#2f6f3a",
              border: "3px solid #f5c400",
              padding: "8px 14px",
              borderRadius: 10,
              color: "white",
              fontWeight: "bold",
              cursor: "default",
            }}
          >
            Parc mécanique
          </button>

          <button
            onClick={() => navigate("/pc-securite-aqua")}
            style={{
              backgroundColor: "#ffffff33",
              border: "3px solid #f5c400",
              padding: "8px 14px",
              borderRadius: 10,
              color: "white",
              fontWeight: "bold",
            }}
          >
            Parc aquatique
          </button>
        </div>

        {/* LOGO */}
        <img
          src="/logo_walygator_maintenance.png"
          alt="logo"
          style={{ height: 70 }}
        />

        {/* LOGOUT */}
        <button
          onClick={handleLogout}
          style={{
            position: "absolute",
            right: 20,
            background: "transparent",
            border: "none",
            cursor: "pointer",
          }}
        >
          <img
            src="/logout_door.png"
            alt=""
            style={{ height: 32, filter: "invert(1)" }}
          />
        </button>
      </div>

      {/* CONTENU */}
      <div style={{ padding: 20 }}>
        <h1>PC Sécurité — Attractions mécaniques</h1>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
            gap: 25,
          }}
        >
          {attractionsList.map((a) => {
            const key = normalizeAttraction(a.nom);
            const record = statuses[key] || {};
            const hasChecklist = validatedToday.has(key);
const isNonSigned = nonSignedToday.has(key);

const incident = incidentsActifs[key];

let displayStatus = "fermee";
let forcedMessage = null;

// ⛔ NON SIGNÉ = PRIORITÉ ABSOLUE
if (isNonSigned) {
  displayStatus = "fermee";
  forcedMessage = "Fermée : checklist non signée";
}

// 🔴 STATUT MANUEL PC SÉCURITÉ
else if (record.manual === true) {
  displayStatus = record.status || "fermee";
}

// ⛔ PAS DE CHECKLIST
else if (!hasChecklist) {
  displayStatus = "fermee";
}

// ✅ SINON OUVERT
else {
  displayStatus = "ouverte";
}

const disableActions = !hasChecklist || isNonSigned;

            return (
              <div
                key={a.nom}
                style={{
                  padding: 15,
                  borderRadius: 14,
                  background: forcedMessage
  ? "#ffb5b5"
  : hasChecklist
  ? colors[displayStatus]
  : "#d9d9d9",

                  opacity: hasChecklist ? 1 : 0.5,
                  boxShadow: "0 2px 6px rgba(0,0,0,0.15)",
                }}
              >
                <img
                  src={`/attractions_meca/${a.image}`}
                  alt={a.nom}
                  style={{
                    width: "100%",
                    height: 150,
                    objectFit: "cover",
                    borderRadius: 10,
                  }}
                />

                <p style={{ marginTop: 10, fontWeight: "bold", textAlign: "center" }}>
                  {a.nom}
                </p>

                <p
  style={{
    textAlign: "center",
    marginBottom: 10,
    fontWeight: forcedMessage ? "bold" : "normal",
    color: forcedMessage ? "#b00000" : "inherit",
  }}
>
  {forcedMessage
    ? forcedMessage
    : hasChecklist
    ? `Statut : ${translateStatus(displayStatus)}`
    : "En attente de checklist…"}
</p>

{incident && displayStatus === "panne" && (
  <p
    style={{
      textAlign: "center",
      fontWeight: "bold",
      color: "#b45f00",
      marginTop: -4, // colle visuellement au statut
    }}
  >
    ⏱ Arrêt depuis {formatDuration(incident)}
  </p>
)}

                <div
  style={{
    display: "flex",
    justifyContent: "space-between",
    marginTop: 12,
    pointerEvents: disableActions ? "none" : "auto",
    opacity: disableActions ? 0.45 : 1,
  }}
>

                  <button
  onClick={() =>
    !disableActions &&
    !isCurrent(displayStatus, "fermee") &&
    updateStatus(key, "fermee")
  }
  disabled={
    disableActions || isCurrent(displayStatus, "fermee")
  }
  style={{
    background: "#ff4d4d", // 🔥 TA COULEUR ORIGINALE
    padding: "6px 10px",
    color: "white",
    borderRadius: 6,
    border: "none",
    fontWeight: "bold",
    cursor:
      disableActions || isCurrent(displayStatus, "fermee")
        ? "not-allowed"
        : "pointer",
    opacity:
      isCurrent(displayStatus, "fermee") ? 0.4 : 1,
  }}
>
  Fermée
</button>
                  <button
  onClick={() =>
    !disableActions &&
    !isCurrent(displayStatus, "ouverte") &&
    updateStatus(key, "ouverte")
  }
  disabled={
    disableActions || isCurrent(displayStatus, "ouverte")
  }
  style={{
    background: "#34c759",
    padding: "6px 10px",
    color: "white",
    borderRadius: 6,
    border: "none",
    fontWeight: "bold",
    cursor:
      disableActions || isCurrent(displayStatus, "ouverte")
        ? "not-allowed"
        : "pointer",
    opacity:
      isCurrent(displayStatus, "ouverte") ? 0.4 : 1,
  }}
>
  Ouverte
</button>
                  <button
  onClick={() =>
    !disableActions &&
    !isCurrent(displayStatus, "panne") &&
    setIncidentModal({ key, name: a.nom, statut: "panne" })
  }
  disabled={
    disableActions || isCurrent(displayStatus, "panne")
  }
  style={{
    background: "#f2c94c",
    padding: "6px 10px",
    color: "black",
    borderRadius: 6,
    border: "none",
    fontWeight: "bold",
    cursor:
      disableActions || isCurrent(displayStatus, "panne")
        ? "not-allowed"
        : "pointer",
    opacity:
      isCurrent(displayStatus, "panne") ? 0.4 : 1,
  }}
>
  En panne
</button>

                  <button
  onClick={() =>
    !disableActions &&
    !isCurrent(displayStatus, "evacuation") &&
    updateStatus(key, "evacuation")
  }
  disabled={
    disableActions || isCurrent(displayStatus, "evacuation")
  }
  style={{
    background: "#4c88ff",
    padding: "6px 10px",
    color: "white",
    borderRadius: 6,
    border: "none",
    fontWeight: "bold",
    cursor:
      disableActions || isCurrent(displayStatus, "evacuation")
        ? "not-allowed"
        : "pointer",
    opacity:
      isCurrent(displayStatus, "evacuation") ? 0.4 : 1,
  }}
>
  Évac
</button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {/* 🔴 MODAL PANNE — UI IDENTIQUE AQUA (SANS GROUPE) */}
{incidentModal && (
  <div style={styles.overlay}>
    <div style={styles.editModal}>
      <div style={{ textAlign: "center", marginBottom: 20 }}>
        <div
          style={{
            fontSize: 22,
            fontWeight: "bold",
            marginBottom: 6,
          }}
        >
          {incidentModal.name}
        </div>

        <div
          style={{
            fontSize: 14,
            color: "#555",
            fontWeight: "bold",
            letterSpacing: 0.5,
          }}
        >
          Raison attraction en panne
        </div>
      </div>

      <label style={styles.modalLabel}>
        Description de la panne
      </label>

      <textarea
        value={incidentReason}
        onChange={(e) => setIncidentReason(e.target.value)}
        rows={4}
        placeholder="Décrire la panne constatée..."
        style={{
          ...styles.pinInput,
          resize: "none",
          textAlign: "left",
          fontFamily: "inherit",
          fontSize: 14,
        }}
        autoFocus
      />

      <div style={styles.hint}>
        Ce message sera enregistré dans l’incident
      </div>

      <div style={styles.modalActions}>
        <button
          style={styles.secondaryBtn}
          onClick={() => {
            setIncidentModal(null);
            setIncidentReason("");
          }}
        >
          Annuler
        </button>

        <button
          style={{
            ...styles.primaryBtn,
            opacity: incidentReason.trim() ? 1 : 0.5,
          }}
          disabled={!incidentReason.trim()}
          onClick={async () => {
            await triggerPanneWithIncident({
              key: incidentModal.key,
              name: incidentModal.name,
              reason: incidentReason.trim(),
            });

            setIncidentModal(null);
            setIncidentReason("");
          }}
        >
          Valider
        </button>
      </div>
    </div>
  </div>
)}
    </div>
  );
}

const styles = {
  overlay: {
    position: "fixed",
    inset: 0,
    backgroundColor: "rgba(0,0,0,0.5)",
    backdropFilter: "blur(6px)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 1000,
  },

  editModal: {
    backgroundColor: "white",
    padding: 26,
    borderRadius: 16,
    width: 420,
    boxShadow: "0 20px 40px rgba(0,0,0,0.35)",
  },

  modalLabel: {
    display: "block",
    fontWeight: "bold",
    marginBottom: 8,
    marginTop: 10,
    fontSize: 14,
  },

  pinInput: {
    width: "100%",
    boxSizing: "border-box",
    padding: "14px 16px",
    fontSize: 14,
    borderRadius: 10,
    border: "2px solid #235630",
    outline: "none",
  },

  modalActions: {
    display: "flex",
    justifyContent: "flex-end",
    gap: 10,
    marginTop: 20,
  },

  primaryBtn: {
    backgroundColor: "#235630",
    color: "white",
    borderRadius: 8,
    padding: "8px 16px",
    border: "none",
    fontWeight: "bold",
    cursor: "pointer",
  },

  secondaryBtn: {
    backgroundColor: "#e0e0e0",
    border: "none",
    padding: "8px 16px",
    borderRadius: 8,
    fontWeight: "bold",
    cursor: "pointer",
  },
};